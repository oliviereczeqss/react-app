export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number; // in PLN
  category: 'przystawki' | 'glowne' | 'desery' | 'napoje';
  tags?: string[];
  image: string;
}

export interface Reservation {
  id: string;
  name: string;
  date: string;
  time: string;
  guests: number;
  phone?: string;
  email?: string;
  notes?: string;
  createdAt: string;
}

export interface GalleryItem {
  id: string;
  url: string;
  caption: string;
  category: 'food' | 'interior';
}
