import React from 'react';
import { Mail, Phone, MapPin, Globe } from 'lucide-react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  const handleLinkClick = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      const offset = 80;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <footer className="bg-bordo-900 text-beige-100 pt-16 pb-8 border-t border-bordo-850">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main Footer content */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 lg:gap-12 mb-12">
          
          {/* Col 1: Brand & Bio (Col 5) */}
          <div className="lg:col-span-5 space-y-6">
            <div className="flex flex-col cursor-pointer" onClick={() => handleLinkClick('home')}>
              <span className="font-serif text-2xl font-bold tracking-wider text-gold-400">
                OSTERIA
              </span>
              <span className="font-serif text-sm tracking-[0.25em] text-white -mt-1 font-semibold">
                BELLA VISTA
              </span>
            </div>
            
            <p className="text-gold-200/70 font-light text-sm leading-relaxed max-w-sm">
              Tradycyjna włoska gościnność w sercu stolicy. Słyniemy z ręcznie robionego makaronu, selekcji win prosto z Italii oraz klimatycznych, niezapomnianych wieczorów.
            </p>

            <div className="flex items-center space-x-4">
              {/* Styled Social Placeholders */}
              <a href="#" className="w-8 h-8 rounded-full border border-gold-400/40 hover:border-gold-400 text-gold-300 hover:text-white flex items-center justify-center transition-all duration-300 bg-white/5">
                <span className="font-serif text-[10px] font-bold">IG</span>
              </a>
              <a href="#" className="w-8 h-8 rounded-full border border-gold-400/40 hover:border-gold-400 text-gold-300 hover:text-white flex items-center justify-center transition-all duration-300 bg-white/5">
                <span className="font-serif text-[10px] font-bold">FB</span>
              </a>
              <a href="#" className="w-8 h-8 rounded-full border border-gold-400/40 hover:border-gold-400 text-gold-300 hover:text-white flex items-center justify-center transition-all duration-300 bg-white/5">
                <span className="font-serif text-[10px] font-bold">TA</span>
              </a>
            </div>
          </div>

          {/* Col 2: Navigation Links (Col 3) */}
          <div className="lg:col-span-3 space-y-4">
            <h4 className="font-serif text-sm uppercase tracking-widest font-bold text-gold-300">
              Szybkie Linki
            </h4>
            <ul className="space-y-2 text-sm text-gold-100/80">
              <li>
                <button onClick={() => handleLinkClick('home')} className="hover:text-gold-400 transition-colors duration-200 text-left cursor-pointer">
                  Strona Główna
                </button>
              </li>
              <li>
                <button onClick={() => handleLinkClick('o-nas')} className="hover:text-gold-400 transition-colors duration-200 text-left cursor-pointer">
                  O nas i lokalizacja
                </button>
              </li>
              <li>
                <button onClick={() => handleLinkClick('menu')} className="hover:text-gold-400 transition-colors duration-200 text-left cursor-pointer">
                  Karta Menu
                </button>
              </li>
              <li>
                <button onClick={() => handleLinkClick('galeria')} className="hover:text-gold-400 transition-colors duration-200 text-left cursor-pointer">
                  Nasza Galeria
                </button>
              </li>
              <li>
                <button onClick={() => handleLinkClick('rezerwacje')} className="hover:text-gold-400 transition-colors duration-200 text-left cursor-pointer">
                  Rezerwacja Stolików
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Quick Contact (Col 4) */}
          <div className="lg:col-span-4 space-y-4 text-sm text-gold-100/80">
            <h4 className="font-serif text-sm uppercase tracking-widest font-bold text-gold-300">
              Kontakt i Adres
            </h4>
            <div className="space-y-3">
              <div className="flex items-start space-x-3">
                <MapPin className="w-4 h-4 text-gold-400 mt-0.5 flex-shrink-0" />
                <span>ul. Piękna 12, Warszawa, Polska</span>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="w-4 h-4 text-gold-400 flex-shrink-0" />
                <a href="tel:+48221234567" className="hover:text-gold-400 transition-colors duration-200">
                  +48 22 123 45 67
                </a>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="w-4 h-4 text-gold-400 flex-shrink-0" />
                <a href="mailto:kontakt@osteriabellavista.pl" className="hover:text-gold-400 transition-colors duration-200">
                  kontakt@osteriabellavista.pl
                </a>
              </div>
              <div className="flex items-center space-x-3">
                <Globe className="w-4 h-4 text-gold-400 flex-shrink-0" />
                <span>www.osteriabellavista.pl</span>
              </div>
            </div>
          </div>

        </div>

        {/* Horizontal separator */}
        <div className="border-t border-bordo-800/80 pt-8 mt-8 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-gold-200/50">
          <p>
            &copy; {currentYear} Osteria Bella Vista. Wszystkie prawa zastrzeżone.
          </p>
          <p className="flex space-x-4">
            <a href="#" className="hover:text-gold-400 transition-colors">Polityka prywatności</a>
            <span>•</span>
            <a href="#" className="hover:text-gold-400 transition-colors">Regulamin rezerwacji</a>
          </p>
        </div>

      </div>
    </footer>
  );
}
