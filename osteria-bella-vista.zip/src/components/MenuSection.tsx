import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MENU_ITEMS } from '../data';
import { MenuItem } from '../types';
import { Sparkles } from 'lucide-react';

export default function MenuSection() {
  const [activeCategory, setActiveCategory] = useState<MenuItem['category']>('przystawki');

  const categories: { id: MenuItem['category']; label: string }[] = [
    { id: 'przystawki', label: 'Przystawki' },
    { id: 'glowne', label: 'Dania Główne' },
    { id: 'desery', label: 'Desery' },
    { id: 'napoje', label: 'Napoje & Wina' },
  ];

  const filteredItems = MENU_ITEMS.filter(item => item.category === activeCategory);

  return (
    <section id="menu" className="py-20 sm:py-28 bg-beige-100 relative">
      {/* Decorative top wave/divider line */}
      <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-gold-400 to-transparent" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="font-serif text-bordo-500 font-medium tracking-widest text-sm uppercase block mb-3">
            Kulinarna Podróż
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-stone-900 tracking-tight mb-4">
            Nasze Menu
          </h2>
          <div className="h-1 w-16 bg-gold-500 mx-auto mb-6" />
          <p className="text-stone-600 font-light leading-relaxed">
            Każde danie to starannie skomponowana kompozycja najwyższej jakości składników, przygotowywana od podstaw z głębokim szacunkiem do włoskiego dziedzictwa kulinarnego.
          </p>
        </div>

        {/* Category Tabs */}
        <div className="flex flex-wrap justify-center gap-2 sm:gap-4 mb-12 sm:mb-16">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-5 py-2.5 sm:px-6 sm:py-3 text-xs sm:text-sm font-sans tracking-widest uppercase font-semibold border rounded-sm transition-all duration-300 cursor-pointer ${
                activeCategory === cat.id
                  ? 'bg-bordo-500 text-white border-bordo-600 shadow-lg shadow-bordo-900/10'
                  : 'bg-white/80 hover:bg-beige-50 text-stone-700 border-stone-200 hover:border-gold-400'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Menu Items Grid */}
        <div className="min-h-[400px]">
          <motion.div 
            layout
            className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-10"
          >
            <AnimatePresence mode="popLayout">
              {filteredItems.map((item) => (
                <motion.div
                  layout
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.4 }}
                  key={item.id}
                  className="bg-white p-5 sm:p-6 rounded-sm shadow-sm hover:shadow-xl transition-shadow duration-300 border border-beige-200 flex flex-col sm:flex-row gap-5 items-start group"
                >
                  {/* Dish Image */}
                  <div className="w-full sm:w-28 h-28 flex-shrink-0 rounded-sm overflow-hidden bg-stone-100 relative">
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    {item.tags?.includes('Bestseller') && (
                      <div className="absolute top-1 left-1 bg-gold-500 text-white text-[8px] uppercase tracking-wider px-1.5 py-0.5 rounded-sm font-bold flex items-center gap-0.5">
                        <Sparkles className="w-2 h-2" />
                        Hit
                      </div>
                    )}
                  </div>

                  {/* Dish Details */}
                  <div className="flex-1 w-full">
                    <div className="flex items-baseline justify-between gap-4 mb-2">
                      <h3 className="font-serif text-lg sm:text-xl font-bold text-stone-900 group-hover:text-bordo-500 transition-colors duration-300">
                        {item.name}
                      </h3>
                      {/* Price Line connecting or standalone */}
                      <span className="font-mono text-base font-bold text-bordo-600 flex-shrink-0">
                        {item.price} PLN
                      </span>
                    </div>

                    {/* Tags */}
                    <div className="flex flex-wrap gap-1.5 mb-3">
                      {item.tags?.map((tag, idx) => (
                        <span 
                          key={idx} 
                          className="text-[9px] font-sans tracking-widest uppercase font-semibold bg-stone-100 text-stone-600 px-2 py-0.5 rounded-full"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>

                    {/* Description */}
                    <p className="text-stone-500 font-light text-xs sm:text-sm leading-relaxed">
                      {item.description}
                    </p>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </motion.div>
        </div>

        {/* Additional dietary info banner */}
        <div className="mt-16 text-center border-t border-beige-200/55 pt-8">
          <p className="text-xs text-stone-500 italic max-w-lg mx-auto">
            Wszystkie nasze makarony są przygotowywane codziennie na świeżo. Jeśli masz jakiekolwiek alergie lub preferencje żywieniowe, prosimy poinformuj o tym obsługę przy składaniu zamówienia.
          </p>
        </div>

      </div>
    </section>
  );
}
