import { MenuItem, GalleryItem } from './types';

export const MENU_ITEMS: MenuItem[] = [
  // Przystawki (Appetizers)
  {
    id: 'p1',
    name: 'Bruschetta al Pomodoro',
    description: 'Grillowane pieczywo rzemieślnicze, dojrzałe pomidory San Marzano, czosnek, świeża bazylia, oliwa z oliwek Extra Virgin.',
    price: 29,
    category: 'przystawki',
    tags: ['Wege', 'Klasyk'],
    image: 'https://images.unsplash.com/photo-1572656631137-7935297eff55?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'p2',
    name: 'Carpaccio di Manzo',
    description: 'Cienkie plastry polędwicy wołowej, świeża rukola, dzikie kapary, płatki parmezanu dojrzewającego 24 miesiące, oliwa truflowa.',
    price: 49,
    category: 'przystawki',
    tags: ['Premium'],
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'p3',
    name: 'Burrata con Pomodorini',
    description: 'Kremowy ser burrata z Apulii, konfitowane pomidorki koktajlowe, domowe pesto bazyliowe, prażone orzeszki piniowe.',
    price: 42,
    category: 'przystawki',
    tags: ['Wege', 'Polecane'],
    image: 'https://images.unsplash.com/photo-1592417817098-8f3d6eb19675?auto=format&fit=crop&w=600&q=80'
  },

  // Dania główne (Mains)
  {
    id: 'dg1',
    name: 'Spaghetti Carbonara',
    description: 'Oryginalna rzymska receptura: rzemieślniczy makaron spaghetti, chrupiące guanciale, kremowy sos z żółtek jaj i sera Pecorino Romano, czarny pieprz.',
    price: 48,
    category: 'glowne',
    tags: ['Oryginał', 'Bestseller'],
    image: 'https://images.unsplash.com/photo-1612874742237-6526221588e3?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'dg2',
    name: 'Risotto ai Funghi',
    description: 'Kremowy ryż Arborio powoli gotowany na bulionie warzywnym z borowikami leśnymi, aromatycznym białym winem, masłem i Parmigiano Reggiano.',
    price: 52,
    category: 'glowne',
    tags: ['Wege', 'Bezglutenowe'],
    image: 'https://images.unsplash.com/photo-1476124369491-e7addf5db371?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'dg3',
    name: 'Tagliatelle al Tartufo',
    description: 'Świeży makaron wstążki z aksamitnym sosem z czarnej trufli, masła i Parmigiano Reggiano, posypany świeżo tartą truflą.',
    price: 58,
    category: 'glowne',
    tags: ['Wege', 'Premium'],
    image: 'https://images.unsplash.com/photo-1645112411341-6c4fd023714a?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'dg4',
    name: 'Filetto di Branzino',
    description: 'Pieczony filet z okonia morskiego, serwowany na grillowanych warzywach śródziemnomorskich z sosem cytrynowo-maślanym i świeżymi ziołami.',
    price: 69,
    category: 'glowne',
    tags: ['Ryba', 'Lekkie'],
    image: 'https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?auto=format&fit=crop&w=600&q=80'
  },

  // Desery (Desserts)
  {
    id: 'd1',
    name: 'Tiramisu Klasyczne',
    description: 'Włoskie biszkopty Savoiardi nasączone mocnym espresso i likierem Amaretto, puszysty krem z sera Mascarpone, posypane gorzkim kakao.',
    price: 28,
    category: 'desery',
    tags: ['Klasyk', 'Bestseller'],
    image: 'https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'd2',
    name: 'Panna Cotta al Lampone',
    description: 'Kremowy deser śmietankowy z nutą prawdziwej wanilii Bourbon z Madagaskaru, podawany z aksamitnym, lekko kwaśnym musem z leśnych malin.',
    price: 26,
    category: 'desery',
    tags: ['Lekkie'],
    image: 'https://images.unsplash.com/photo-1488477181946-6428a0291777?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'd3',
    name: 'Fondant al Cioccolato',
    description: 'Ciepłe ciastko z belgijskiej czekolady z płynnym, aksamitnym wnętrzem, podawane z rzemieślniczymi lodami waniliowymi i świeżą miętą.',
    price: 32,
    category: 'desery',
    tags: ['Na ciepło'],
    image: 'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?auto=format&fit=crop&w=600&q=80'
  },

  // Napoje (Drinks)
  {
    id: 'n1',
    name: 'Wino Domowe Osteria (Rosso / Bianco)',
    description: 'Wyselekcjonowane, klasyczne wino z malowniczych winnic regionu Veneto. Doskonale zbalansowane, pasujące do naszych dań.',
    price: 18, // kieliszek
    category: 'napoje',
    tags: ['Wino', 'Polecane'],
    image: 'https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'n2',
    name: 'Aperol Spritz',
    description: 'Klasyczny włoski aperitif: Aperol, oryginalne włoskie Prosecco DOC, woda gazowana, plaster świeżej pomarańczy i lód.',
    price: 34,
    category: 'napoje',
    tags: ['Koktajl', 'Orzeźwiające'],
    image: 'https://images.unsplash.com/photo-1560512823-829485b8bf24?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'n3',
    name: 'Limonata della Casa',
    description: 'Tradycyjna, mocno orzeźwiająca lemoniada ze świeżo wyciskanych sycylijskich cytryn, z gałązkami mięty i odrobiną brązowego cukru.',
    price: 18,
    category: 'napoje',
    tags: ['Bezalkoholowe', 'Domowe'],
    image: 'https://images.unsplash.com/photo-1534353436294-0dbd4bdac845?auto=format&fit=crop&w=600&q=80'
  }
];

export const GALLERY_ITEMS: GalleryItem[] = [
  {
    id: 'g1',
    url: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80',
    caption: 'Nasza ciepła, przytulna sala główna z klimatycznym oświetleniem.',
    category: 'interior'
  },
  {
    id: 'g2',
    url: 'https://images.unsplash.com/photo-1572656631137-7935297eff55?auto=format&fit=crop&w=800&q=80',
    caption: 'Świeża Bruschetta al Pomodoro przygotowywana codziennie rano.',
    category: 'food'
  },
  {
    id: 'g3',
    url: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&q=80',
    caption: 'Kameralny kącik idealny na romantyczną kolację przy winie.',
    category: 'interior'
  },
  {
    id: 'g4',
    url: 'https://images.unsplash.com/photo-1612874742237-6526221588e3?auto=format&fit=crop&w=800&q=80',
    caption: 'Nasze słynne rzymskie Spaghetti Carbonara pełne kremowego smaku.',
    category: 'food'
  },
  {
    id: 'g5',
    url: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=800&q=80',
    caption: 'Nasz Szef Kuchni dba o każdy detal na talerzu.',
    category: 'interior'
  },
  {
    id: 'g6',
    url: 'https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?auto=format&fit=crop&w=800&q=80',
    caption: 'Domowe Tiramisu oprószone najwyższej jakości ciemnym kakao.',
    category: 'food'
  }
];

export const TESTIMONIALS = [
  {
    name: 'Katarzyna Wiśniewska',
    role: 'Lokalna przewodniczka, Warszawa',
    comment: 'Prawdziwe rzymskie wakacje w środku Warszawy! Carbonara bez śmietanki, idealne guanciale i cudownie kremowy sos z żółtek. Do tego świetna, nienachalna obsługa.',
    rating: 5
  },
  {
    name: 'Mateusz Kowalski',
    role: 'Miłośnik kuchni włoskiej',
    comment: 'Cudowny klimat, elegancko ale bardzo przytulnie. Burrata rozpływa się w ustach, a tiramisu to po prostu poezja smaku. Na pewno będziemy tu wracać z żoną.',
    rating: 5
  },
  {
    name: 'Anna i Piotr',
    role: 'Klienci regularni',
    comment: 'Osteria Bella Vista stała się naszym ulubionym miejscem na rodzinne obiady i rocznice. Przepyszne jedzenie, świetne wina i ten niesamowity, ciepły zapach od wejścia.',
    rating: 5
  }
];

export const OPENING_HOURS = {
  weekdays: 'Poniedziałek – Czwartek: 12:00 – 22:00',
  fridaySaturday: 'Piątek – Sobota: 12:00 – 23:00',
  sunday: 'Niedziela: 12:00 – 21:00'
};
