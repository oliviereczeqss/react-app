import React from 'react';
import { motion } from 'motion/react';
import { Star, Quote } from 'lucide-react';
import { TESTIMONIALS } from '../data';

export default function Testimonials() {
  return (
    <section className="py-20 bg-beige-100 relative overflow-hidden">
      {/* Decorative vertical divider lines */}
      <div className="absolute top-0 bottom-0 left-1/4 w-[1px] bg-stone-200/30 hidden md:block" />
      <div className="absolute top-0 bottom-0 right-1/4 w-[1px] bg-stone-200/30 hidden md:block" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="font-serif text-bordo-500 font-medium tracking-widest text-sm uppercase block mb-3">
            Opinie naszych gości
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-stone-900 tracking-tight mb-4">
            Słowa Uznania
          </h2>
          <div className="h-1 w-16 bg-gold-500 mx-auto mb-6" />
        </div>

        {/* Testimonials Deck */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {TESTIMONIALS.map((t, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 35 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.6, delay: idx * 0.15 }}
              className="bg-white p-8 rounded-sm shadow-md hover:shadow-xl transition-luxury border border-beige-200 relative flex flex-col justify-between"
            >
              {/* Quote icon watermark */}
              <Quote className="absolute right-6 top-6 w-12 h-12 text-gold-200/20" />

              <div>
                {/* Stars */}
                <div className="flex space-x-1 mb-6">
                  {[...Array(t.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-gold-500 text-gold-500" />
                  ))}
                </div>

                {/* Comment */}
                <p className="text-stone-700 font-light italic leading-relaxed text-sm mb-8">
                  „{t.comment}”
                </p>
              </div>

              {/* Author Info */}
              <div className="border-t border-beige-100 pt-4 flex flex-col">
                <span className="font-serif text-base font-bold text-stone-900">{t.name}</span>
                <span className="text-[11px] font-sans tracking-wide text-gold-600 font-semibold uppercase mt-0.5">{t.role}</span>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Dynamic call to action */}
        <div className="mt-16 text-center">
          <span className="inline-block px-4 py-2 bg-white rounded-full border border-beige-200 text-xs text-stone-600 font-medium shadow-sm">
            Ocena na TripAdvisor: ★★★★☆ 4.8/5 na podstawie ponad 450 recenzji
          </span>
        </div>

      </div>
    </section>
  );
}
