import React from 'react';
import { motion } from 'motion/react';
import { Phone, Mail, MapPin, Clock, Navigation, ExternalLink, CalendarDays } from 'lucide-react';
import { OPENING_HOURS } from '../data';

export default function Contact() {
  return (
    <section id="kontakt" className="py-20 sm:py-28 bg-beige-50 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="font-serif text-bordo-500 font-medium tracking-widest text-sm uppercase block mb-3">
            Zapraszamy do kontaktu
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-stone-900 tracking-tight mb-4">
            Gdzie Nas Znaleźć?
          </h2>
          <div className="h-1 w-16 bg-gold-500 mx-auto mb-6" />
          <p className="text-stone-600 font-light leading-relaxed">
            Niezależnie od tego, czy chcesz zarezerwować stół, zapytać o imprezę okolicznościową, czy po prostu dowiedzieć się więcej o naszej kuchni – czekamy na Twój kontakt.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-stretch">
          
          {/* Contact Details (Col Span 5) */}
          <div className="lg:col-span-5 flex flex-col justify-between space-y-8">
            
            {/* Quick Contact Cards */}
            <div className="space-y-6">
              
              {/* Card: Address */}
              <div className="bg-white p-6 rounded-sm shadow-sm border border-beige-200 flex items-start space-x-4">
                <div className="bg-gold-100 p-3 rounded-sm border border-gold-200 flex-shrink-0">
                  <MapPin className="w-5 h-5 text-bordo-500" />
                </div>
                <div>
                  <h3 className="font-serif text-base font-bold text-stone-900 mb-1">Nasza Lokalizacja</h3>
                  <p className="text-stone-600 font-light text-sm">
                    ul. Piękna 12, 00-549 Warszawa
                  </p>
                  <p className="text-stone-500 text-xs font-light mt-1">
                    Śródmieście Południowe, naprzeciwko Parku Ujazdowskiego
                  </p>
                </div>
              </div>

              {/* Card: Phone */}
              <div className="bg-white p-6 rounded-sm shadow-sm border border-beige-200 flex items-start space-x-4">
                <div className="bg-gold-100 p-3 rounded-sm border border-gold-200 flex-shrink-0">
                  <Phone className="w-5 h-5 text-bordo-500" />
                </div>
                <div>
                  <h3 className="font-serif text-base font-bold text-stone-900 mb-1">Zadzwoń do nas</h3>
                  <a href="tel:+48221234567" className="text-bordo-500 hover:text-bordo-600 font-mono font-bold text-sm hover:underline block">
                    +48 22 123 45 67
                  </a>
                  <p className="text-stone-500 text-xs font-light mt-1">
                    Rezerwacje grupowe powyżej 10 osób: <span className="font-mono">+48 501 987 654</span>
                  </p>
                </div>
              </div>

              {/* Card: Email */}
              <div className="bg-white p-6 rounded-sm shadow-sm border border-beige-200 flex items-start space-x-4">
                <div className="bg-gold-100 p-3 rounded-sm border border-gold-200 flex-shrink-0">
                  <Mail className="w-5 h-5 text-bordo-500" />
                </div>
                <div>
                  <h3 className="font-serif text-base font-bold text-stone-900 mb-1">Napisz do nas</h3>
                  <a href="mailto:kontakt@osteriabellavista.pl" className="text-stone-700 hover:text-bordo-500 text-sm font-medium hover:underline block">
                    kontakt@osteriabellavista.pl
                  </a>
                  <p className="text-stone-500 text-xs font-light mt-1">
                    Odpowiadamy w ciągu maksymalnie 24 godzin.
                  </p>
                </div>
              </div>

            </div>

            {/* Opening Hours Widget */}
            <div className="bg-bordo-500 text-white p-6 sm:p-8 rounded-sm shadow-md border border-bordo-600/30">
              <h3 className="font-serif text-lg font-bold text-gold-300 mb-4 flex items-center gap-2">
                <Clock className="w-5 h-5" /> Godziny Otwarcia
              </h3>
              <div className="space-y-3 text-xs sm:text-sm font-sans">
                <div className="flex justify-between border-b border-bordo-400/20 pb-2">
                  <span className="text-gold-200/90 font-medium">Poniedziałek – Czwartek</span>
                  <span className="font-mono font-semibold">12:00 – 22:00</span>
                </div>
                <div className="flex justify-between border-b border-bordo-400/20 pb-2">
                  <span className="text-gold-200/90 font-medium">Piątek – Sobota</span>
                  <span className="font-mono font-semibold">12:00 – 23:00</span>
                </div>
                <div className="flex justify-between pb-1">
                  <span className="text-gold-200/90 font-medium">Niedziela</span>
                  <span className="font-mono font-semibold">12:00 – 21:00</span>
                </div>
              </div>
            </div>

          </div>

          {/* Interactive Custom Google Map Placeholder (Col Span 7) */}
          <div className="lg:col-span-7 flex flex-col">
            <div className="relative flex-1 min-h-[350px] lg:min-h-[450px] bg-stone-900 rounded-sm overflow-hidden shadow-lg border border-beige-200 flex flex-col justify-between group">
              
              {/* Stylized Simulated Map Design */}
              <div 
                className="absolute inset-0 bg-cover bg-center opacity-75 mix-blend-luminosity filter saturate-50 group-hover:scale-102 transition-transform duration-[4s]"
                style={{
                  backgroundImage: `url('https://images.unsplash.com/photo-1524661135-423995f22d0b?auto=format&fit=crop&w=1200&q=80')` // warm architectural abstract map feel
                }}
              />
              {/* Simulated Map streets grid with canvas overlays to look incredibly premium */}
              <div className="absolute inset-0 bg-bordo-950/20" />
              
              {/* Premium Floating Indicator for Address */}
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-10 flex flex-col items-center">
                <div className="relative">
                  {/* Ripples */}
                  <div className="absolute inset-0 rounded-full bg-bordo-500 scale-200 opacity-20 animate-ping" />
                  <div className="absolute inset-0 rounded-full bg-gold-400 scale-150 opacity-35 animate-pulse" />
                  
                  {/* Pin Circle */}
                  <div className="relative w-12 h-12 bg-bordo-500 rounded-full border-2 border-white shadow-xl flex items-center justify-center">
                    <span className="font-serif text-white font-bold text-[10px]">O.B.V</span>
                  </div>
                </div>
                
                {/* Floating Map tooltip */}
                <div className="bg-white/95 backdrop-blur-sm text-stone-900 rounded-md p-3 shadow-2xl border border-gold-300 text-center mt-3 max-w-[200px]">
                  <span className="font-serif text-xs font-bold block text-bordo-500">Osteria Bella Vista</span>
                  <span className="text-[10px] text-stone-600 block mt-0.5">ul. Piękna 12, Warszawa</span>
                </div>
              </div>

              {/* Map controls decorative buttons */}
              <div className="absolute right-4 top-4 z-10 flex flex-col gap-2">
                <div className="bg-white/90 backdrop-blur-sm p-1.5 rounded-sm shadow-md text-stone-700 font-bold font-mono text-xs text-center w-8 select-none">+</div>
                <div className="bg-white/90 backdrop-blur-sm p-1.5 rounded-sm shadow-md text-stone-700 font-bold font-mono text-xs text-center w-8 select-none">-</div>
              </div>

              {/* Interactive bottom bar with navigation launcher */}
              <div className="absolute bottom-0 left-0 right-0 z-10 bg-white/95 backdrop-blur-md p-4 border-t border-beige-200 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                <div className="text-xs">
                  <span className="font-bold text-stone-900 block">Warszawa Śródmieście</span>
                  <span className="text-stone-500 block">Łatwy dojazd tramwajem lub metrem (Stacja Metro Politechnika)</span>
                </div>
                
                <a 
                  href="https://maps.google.com/?q=Piękna+12,+Warszawa" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center justify-center space-x-2 bg-stone-900 hover:bg-stone-850 active:bg-stone-950 text-white px-4 py-2.5 rounded-sm font-sans text-xs uppercase tracking-wider font-semibold shadow-md transition-colors duration-200 cursor-pointer"
                >
                  <Navigation className="w-3.5 h-3.5 text-gold-400" />
                  <span>Uruchom nawigację</span>
                  <ExternalLink className="w-3 h-3 text-stone-400" />
                </a>
              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
