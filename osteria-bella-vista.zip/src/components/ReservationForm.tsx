import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CalendarDays, Users, Clock, User, CheckCircle2, Phone, Mail, FileText, Trash2 } from 'lucide-react';
import { Reservation } from '../types';

export default function ReservationForm() {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    date: '',
    time: '18:00',
    guests: 2,
    notes: ''
  });

  const [activeReservations, setActiveReservations] = useState<Reservation[]>([]);
  const [isSuccess, setIsSuccess] = useState(false);
  const [latestBooking, setLatestBooking] = useState<Reservation | null>(null);
  const [errorMsg, setErrorMsg] = useState('');

  // Hours available for booking (from 12:00 to 22:00 in 30m steps)
  const bookingTimes = [
    '12:00', '12:30', '13:00', '13:30', '14:00', '14:30', '15:00', '15:30',
    '16:00', '16:30', '17:00', '17:30', '18:00', '18:30', '19:00', '19:30',
    '20:00', '20:30', '21:00', '21:30'
  ];

  // Load existing reservations from localStorage
  useEffect(() => {
    const stored = localStorage.getItem('osteriabv_bookings');
    if (stored) {
      try {
        setActiveReservations(JSON.parse(stored));
      } catch (e) {
        console.error('Failed to load bookings', e);
      }
    }
  }, []);

  // Save reservations
  const saveReservations = (updated: Reservation[]) => {
    localStorage.setItem('osteriabv_bookings', JSON.stringify(updated));
    setActiveReservations(updated);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    // Validations
    if (!formData.name.trim()) {
      setErrorMsg('Wprowadź imię i nazwisko.');
      return;
    }
    if (!formData.date) {
      setErrorMsg('Wybierz datę rezerwacji.');
      return;
    }
    if (!formData.phone.trim()) {
      setErrorMsg('Wprowadź numer telefonu do kontaktu.');
      return;
    }

    // Set minimal date validation to today or future
    const selectedDate = new Date(formData.date);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    if (selectedDate < today) {
      setErrorMsg('Data rezerwacji nie może być z przeszłości.');
      return;
    }

    // Create reservation object
    const newReservation: Reservation = {
      id: 'res_' + Math.random().toString(36).substr(2, 9),
      name: formData.name,
      phone: formData.phone,
      email: formData.email,
      date: formData.date,
      time: formData.time,
      guests: Number(formData.guests),
      notes: formData.notes,
      createdAt: new Date().toISOString()
    };

    const updatedBookings = [newReservation, ...activeReservations];
    saveReservations(updatedBookings);
    setLatestBooking(newReservation);
    setIsSuccess(true);

    // Reset form fields
    setFormData({
      name: '',
      phone: '',
      email: '',
      date: '',
      time: '18:00',
      guests: 2,
      notes: ''
    });
  };

  const cancelReservation = (id: string) => {
    const filtered = activeReservations.filter(res => res.id !== id);
    saveReservations(filtered);
  };

  // Get tomorrow's date string for input default min date
  const getTodayDateString = () => {
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const dd = String(today.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
  };

  return (
    <section id="rezerwacje" className="py-20 sm:py-28 bg-beige-100 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="font-serif text-bordo-500 font-medium tracking-widest text-sm uppercase block mb-3">
            Zarezerwuj Stolik
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-stone-900 tracking-tight mb-4">
            Doświadcz Wyjątkowej Kolacji
          </h2>
          <div className="h-1 w-16 bg-gold-500 mx-auto mb-6" />
          <p className="text-stone-600 font-light leading-relaxed">
            Zalecamy rezerwację stolika z wyprzedzeniem, szczególnie na weekendowe wieczory, by zagwarantować sobie najlepsze doświadczenie kulinarne.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Reservation Card / Form (Col Span 7) */}
          <div className="lg:col-span-7 bg-white p-6 sm:p-10 rounded-sm shadow-xl border border-beige-200">
            <AnimatePresence mode="wait">
              {!isSuccess ? (
                <motion.form
                  key="booking-form"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  onSubmit={handleSubmit}
                  className="space-y-6"
                >
                  <h3 className="font-serif text-2xl font-bold text-stone-900 mb-2 border-b border-beige-100 pb-4">
                    Karta Rezerwacji Online
                  </h3>

                  {errorMsg && (
                    <div className="bg-red-50 text-red-700 text-sm p-4 rounded-sm border-l-4 border-red-600">
                      {errorMsg}
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    {/* Full name */}
                    <div className="flex flex-col space-y-1">
                      <label className="text-xs uppercase tracking-wider font-semibold text-stone-600 flex items-center gap-1.5">
                        <User className="w-3.5 h-3.5 text-gold-500" /> Imię i Nazwisko *
                      </label>
                      <input
                        type="text"
                        name="name"
                        value={formData.name}
                        onChange={handleInputChange}
                        placeholder="np. Jan Kowalski"
                        className="w-full bg-beige-50 border border-stone-200 focus:border-gold-500 focus:ring-1 focus:ring-gold-400 p-3 rounded-sm text-stone-850 placeholder-stone-400 outline-none transition-all duration-200 text-sm"
                        required
                      />
                    </div>

                    {/* Phone Number */}
                    <div className="flex flex-col space-y-1">
                      <label className="text-xs uppercase tracking-wider font-semibold text-stone-600 flex items-center gap-1.5">
                        <Phone className="w-3.5 h-3.5 text-gold-500" /> Numer Telefonu *
                      </label>
                      <input
                        type="tel"
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        placeholder="np. +48 500 123 456"
                        className="w-full bg-beige-50 border border-stone-200 focus:border-gold-500 focus:ring-1 focus:ring-gold-400 p-3 rounded-sm text-stone-850 placeholder-stone-400 outline-none transition-all duration-200 text-sm"
                        required
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    {/* E-mail address */}
                    <div className="flex flex-col space-y-1">
                      <label className="text-xs uppercase tracking-wider font-semibold text-stone-600 flex items-center gap-1.5">
                        <Mail className="w-3.5 h-3.5 text-gold-500" /> Adres E-mail
                      </label>
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        placeholder="np. jan.kowalski@email.pl"
                        className="w-full bg-beige-50 border border-stone-200 focus:border-gold-500 focus:ring-1 focus:ring-gold-400 p-3 rounded-sm text-stone-850 placeholder-stone-400 outline-none transition-all duration-200 text-sm"
                      />
                    </div>

                    {/* Number of guests */}
                    <div className="flex flex-col space-y-1">
                      <label className="text-xs uppercase tracking-wider font-semibold text-stone-600 flex items-center gap-1.5">
                        <Users className="w-3.5 h-3.5 text-gold-500" /> Liczba Osób *
                      </label>
                      <select
                        name="guests"
                        value={formData.guests}
                        onChange={handleInputChange}
                        className="w-full bg-beige-50 border border-stone-200 focus:border-gold-500 focus:ring-1 focus:ring-gold-400 p-3 rounded-sm text-stone-850 outline-none transition-all duration-200 text-sm"
                      >
                        {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(num => (
                          <option key={num} value={num}>
                            {num} {num === 1 ? 'osoba' : num < 5 ? 'osoby' : 'osób'}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    {/* Date */}
                    <div className="flex flex-col space-y-1">
                      <label className="text-xs uppercase tracking-wider font-semibold text-stone-600 flex items-center gap-1.5">
                        <CalendarDays className="w-3.5 h-3.5 text-gold-500" /> Data Rezerwacji *
                      </label>
                      <input
                        type="date"
                        name="date"
                        value={formData.date}
                        onChange={handleInputChange}
                        min={getTodayDateString()}
                        className="w-full bg-beige-50 border border-stone-200 focus:border-gold-500 focus:ring-1 focus:ring-gold-400 p-3 rounded-sm text-stone-850 outline-none transition-all duration-200 text-sm"
                        required
                      />
                    </div>

                    {/* Time */}
                    <div className="flex flex-col space-y-1">
                      <label className="text-xs uppercase tracking-wider font-semibold text-stone-600 flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-gold-500" /> Godzina Rezerwacji *
                      </label>
                      <select
                        name="time"
                        value={formData.time}
                        onChange={handleInputChange}
                        className="w-full bg-beige-50 border border-stone-200 focus:border-gold-500 focus:ring-1 focus:ring-gold-400 p-3 rounded-sm text-stone-850 outline-none transition-all duration-200 text-sm"
                      >
                        {bookingTimes.map(t => (
                          <option key={t} value={t}>{t}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* Special notes */}
                  <div className="flex flex-col space-y-1">
                    <label className="text-xs uppercase tracking-wider font-semibold text-stone-600 flex items-center gap-1.5">
                      <FileText className="w-3.5 h-3.5 text-gold-500" /> Uwagi Specjalne / Życzenia
                    </label>
                    <textarea
                      name="notes"
                      value={formData.notes}
                      onChange={handleInputChange}
                      placeholder="np. Stolik przy oknie, krzesełko dla dziecka, rocznica, alergia pokarmowa..."
                      rows={3}
                      className="w-full bg-beige-50 border border-stone-200 focus:border-gold-500 focus:ring-1 focus:ring-gold-400 p-3 rounded-sm text-stone-850 placeholder-stone-400 outline-none transition-all duration-200 text-sm resize-none"
                    />
                  </div>

                  {/* Submit Button */}
                  <button
                    type="submit"
                    className="w-full bg-bordo-500 hover:bg-bordo-600 active:bg-bordo-700 text-white font-sans font-bold text-xs uppercase tracking-widest py-4 rounded-sm shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-0.5 cursor-pointer border border-bordo-600/30"
                  >
                    Rezerwuj Stolik Teraz
                  </button>
                </motion.form>
              ) : (
                <motion.div
                  key="booking-success"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="text-center py-8 space-y-6"
                >
                  <div className="mx-auto w-16 h-16 bg-emerald-50 text-emerald-600 flex items-center justify-center rounded-full border border-emerald-200">
                    <CheckCircle2 className="w-10 h-10" />
                  </div>
                  
                  <div>
                    <h3 className="font-serif text-3xl font-bold text-stone-900 mb-2">
                      Dziękujemy za rezerwację!
                    </h3>
                    <p className="text-stone-600 text-sm font-light max-w-md mx-auto">
                      Twój stolik w Osteria Bella Vista został pomyślnie zarezerwowany. Potwierdzenie wysłaliśmy również na Twój adres e-mail. Do zobaczenia!
                    </p>
                  </div>

                  {latestBooking && (
                    <div className="bg-gold-50 border border-gold-200 max-w-md mx-auto rounded-sm p-6 text-left space-y-4 shadow-inner">
                      <div className="border-b border-gold-200/50 pb-3 text-center">
                        <span className="font-serif text-xs uppercase tracking-widest text-gold-700 font-bold block">
                          KOD REZERWACJI: {latestBooking.id.toUpperCase()}
                        </span>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-y-3 gap-x-4 text-xs font-sans">
                        <div>
                          <span className="text-stone-500 font-semibold uppercase block tracking-wider text-[10px]">Gość</span>
                          <span className="text-stone-850 font-bold">{latestBooking.name}</span>
                        </div>
                        <div>
                          <span className="text-stone-500 font-semibold uppercase block tracking-wider text-[10px]">Liczba osób</span>
                          <span className="text-stone-850 font-bold">{latestBooking.guests} {latestBooking.guests === 1 ? 'osoba' : 'osoby'}</span>
                        </div>
                        <div>
                          <span className="text-stone-500 font-semibold uppercase block tracking-wider text-[10px]">Data</span>
                          <span className="text-stone-850 font-bold">{latestBooking.date}</span>
                        </div>
                        <div>
                          <span className="text-stone-500 font-semibold uppercase block tracking-wider text-[10px]">Godzina</span>
                          <span className="text-stone-850 font-bold">{latestBooking.time}</span>
                        </div>
                      </div>

                      {latestBooking.notes && (
                        <div className="border-t border-gold-200/50 pt-3 text-xs">
                          <span className="text-stone-500 font-semibold uppercase block tracking-wider text-[10px] mb-1">Uwagi</span>
                          <span className="text-stone-800 italic">{latestBooking.notes}</span>
                        </div>
                      )}
                    </div>
                  )}

                  <button
                    onClick={() => setIsSuccess(false)}
                    className="bg-stone-900 hover:bg-stone-800 text-white font-sans font-semibold text-xs uppercase tracking-wider px-6 py-3 rounded-sm transition-colors duration-200 cursor-pointer"
                  >
                    Zarezerwuj kolejny stolik
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Practical Info & Booking list sidebar (Col Span 5) */}
          <div className="lg:col-span-5 space-y-8">
            {/* Practical information card */}
            <div className="bg-bordo-500 text-white p-8 rounded-sm shadow-xl border border-bordo-600/30">
              <h3 className="font-serif text-xl font-bold text-gold-300 mb-4 pb-2 border-b border-bordo-400/30">
                Informacje dla Gości
              </h3>
              <ul className="space-y-4 text-sm font-light text-gold-100/90">
                <li className="flex items-start space-x-3">
                  <div className="w-1.5 h-1.5 bg-gold-400 rounded-full mt-2 flex-shrink-0" />
                  <span>Stoliki rezerwujemy na maksymalnie **2.5 godziny**. Jeśli chcesz przedłużyć ten czas, skontaktuj się z nami telefonicznie.</span>
                </li>
                <li className="flex items-start space-x-3">
                  <div className="w-1.5 h-1.5 bg-gold-400 rounded-full mt-2 flex-shrink-0" />
                  <span>Rezerwację przetrzymujemy przez maksymalnie **15 minut** po wyznaczonej godzinie. Spóźnienia prosimy zgłaszać.</span>
                </li>
                <li className="flex items-start space-x-3">
                  <div className="w-1.5 h-1.5 bg-gold-400 rounded-full mt-2 flex-shrink-0" />
                  <span>Dla grup powyżej **8 osób** doliczamy serwis serwisowy w wysokości **10%** i sugerujemy wcześniejszy dobór menu.</span>
                </li>
              </ul>
            </div>

            {/* Live bookings in LocalStorage list */}
            {activeReservations.length > 0 && (
              <div className="bg-white p-6 sm:p-8 rounded-sm shadow-md border border-beige-200">
                <h3 className="font-serif text-lg font-bold text-stone-900 mb-4 pb-2 border-b border-beige-100 flex items-center justify-between">
                  <span>Twoje Rezerwacje ({activeReservations.length})</span>
                  <span className="text-[10px] font-sans tracking-widest text-gold-600 uppercase font-bold">W pamięci</span>
                </h3>
                
                <div className="space-y-4 max-h-[250px] overflow-y-auto pr-2">
                  {activeReservations.map((res) => (
                    <div 
                      key={res.id}
                      className="text-xs bg-beige-50 hover:bg-beige-100/50 p-3 rounded-sm border border-beige-200 flex justify-between items-center transition-colors duration-200"
                    >
                      <div className="space-y-1">
                        <div className="font-bold text-stone-900">{res.name}</div>
                        <div className="text-stone-500 font-medium">
                          {res.date} o godz. <span className="font-semibold text-bordo-600">{res.time}</span> ({res.guests} os.)
                        </div>
                      </div>
                      
                      <button
                        onClick={() => cancelReservation(res.id)}
                        className="p-1.5 rounded-full text-stone-400 hover:text-red-600 hover:bg-red-50 transition-colors duration-200 cursor-pointer"
                        title="Anuluj rezerwację"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

        </div>
      </div>
    </section>
  );
}
