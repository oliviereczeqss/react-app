import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { GALLERY_ITEMS } from '../data';
import { GalleryItem } from '../types';
import { X, ZoomIn, Eye } from 'lucide-react';

export default function Gallery() {
  const [filter, setFilter] = useState<'all' | 'food' | 'interior'>('all');
  const [selectedImage, setSelectedImage] = useState<GalleryItem | null>(null);

  const filteredItems = GALLERY_ITEMS.filter(item => {
    if (filter === 'all') return true;
    return item.category === filter;
  });

  return (
    <section id="galeria" className="py-20 sm:py-28 bg-beige-50 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="font-serif text-bordo-500 font-medium tracking-widest text-sm uppercase block mb-3">
            Oczami Zmysłów
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-stone-900 tracking-tight mb-4">
            Galeria Smaków & Wnętrz
          </h2>
          <div className="h-1 w-16 bg-gold-500 mx-auto mb-6" />
          <p className="text-stone-600 font-light leading-relaxed">
            Zajrzyj do naszej kuchni i poczuj niepowtarzalny klimat Osteria Bella Vista. Ciepłe światło świec, eleganckie detale i zjawiskowe potrawy czekają na Ciebie.
          </p>
        </div>

        {/* Gallery Filter Tabs */}
        <div className="flex justify-center gap-4 mb-12">
          <button
            onClick={() => setFilter('all')}
            className={`px-4 py-2 text-xs font-sans tracking-wider uppercase font-semibold border-b-2 transition-all duration-300 cursor-pointer ${
              filter === 'all'
                ? 'border-bordo-500 text-bordo-600'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            Wszystko
          </button>
          <button
            onClick={() => setFilter('food')}
            className={`px-4 py-2 text-xs font-sans tracking-wider uppercase font-semibold border-b-2 transition-all duration-300 cursor-pointer ${
              filter === 'food'
                ? 'border-bordo-500 text-bordo-600'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            Nasze Potrawy
          </button>
          <button
            onClick={() => setFilter('interior')}
            className={`px-4 py-2 text-xs font-sans tracking-wider uppercase font-semibold border-b-2 transition-all duration-300 cursor-pointer ${
              filter === 'interior'
                ? 'border-bordo-500 text-bordo-600'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            Wnętrza
          </button>
        </div>

        {/* Grid Container */}
        <div className="min-h-[400px]">
          <motion.div 
            layout 
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8"
          >
            <AnimatePresence mode="popLayout">
              {filteredItems.map((item) => (
                <motion.div
                  layout
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ duration: 0.4 }}
                  key={item.id}
                  onClick={() => setSelectedImage(item)}
                  className="relative aspect-square sm:aspect-video md:aspect-square rounded-sm overflow-hidden group cursor-pointer shadow-md hover:shadow-xl transition-all duration-300"
                >
                  {/* Photo */}
                  <img
                    src={item.url}
                    alt={item.caption}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                    loading="lazy"
                  />

                  {/* Dark Elegant Hover Overlay */}
                  <div className="absolute inset-0 bg-bordo-950/70 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-between p-6">
                    <div className="flex justify-end">
                      <div className="bg-white/20 p-2 rounded-full backdrop-blur-sm">
                        <Eye className="w-5 h-5 text-white" />
                      </div>
                    </div>
                    
                    <div className="transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                      <span className="font-mono text-[10px] tracking-widest text-gold-400 uppercase mb-1 block">
                        {item.category === 'food' ? 'Kuchnia' : 'Wnętrze'}
                      </span>
                      <p className="font-serif text-sm text-white font-medium leading-snug">
                        {item.caption}
                      </p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </motion.div>
        </div>

      </div>

      {/* Lightbox Modal */}
      <AnimatePresence>
        {selectedImage && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-stone-950/95 backdrop-blur-md flex items-center justify-center p-4 sm:p-6"
            onClick={() => setSelectedImage(null)}
          >
            {/* Close button */}
            <button
              onClick={() => setSelectedImage(null)}
              className="absolute top-6 right-6 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors duration-200 cursor-pointer"
              aria-label="Zamknij"
            >
              <X className="w-6 h-6" />
            </button>

            {/* Modal Card */}
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              transition={{ type: 'spring', damping: 25, stiffness: 300 }}
              className="max-w-4xl w-full bg-stone-900 rounded-sm overflow-hidden shadow-2xl border border-stone-850"
              onClick={(e) => e.stopPropagation()} // stop close on clicking content
            >
              <div className="relative aspect-video max-h-[70vh] bg-stone-950 flex items-center justify-center">
                <img
                  src={selectedImage.url}
                  alt={selectedImage.caption}
                  className="max-w-full max-h-full object-contain"
                />
              </div>
              <div className="p-6 bg-stone-900 text-white">
                <span className="font-mono text-xs tracking-widest text-gold-400 uppercase mb-2 block font-semibold">
                  {selectedImage.category === 'food' ? 'Kulinaria' : 'Lokal'}
                </span>
                <p className="font-serif text-lg text-stone-100 italic">
                  „{selectedImage.caption}”
                </p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
