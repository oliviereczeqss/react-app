/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import MenuSection from './components/MenuSection';
import Gallery from './components/Gallery';
import ReservationForm from './components/ReservationForm';
import Testimonials from './components/Testimonials';
import Contact from './components/Contact';
import Footer from './components/Footer';

export default function App() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      const offset = 80; // height of sticky navbar
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <div className="min-h-screen bg-beige-50 text-stone-900 selection:bg-bordo-200 selection:text-bordo-900">
      {/* Navbar with smooth scroll triggers */}
      <Navbar onReserveClick={() => scrollToSection('rezerwacje')} />

      {/* Hero Section */}
      <Hero 
        onReserveClick={() => scrollToSection('rezerwacje')} 
        onMenuClick={() => scrollToSection('menu')} 
      />

      {/* About Section */}
      <About />

      {/* Menu Cards */}
      <MenuSection />

      {/* Gallery Section */}
      <Gallery />

      {/* Testimonials Deck */}
      <Testimonials />

      {/* Booking Form */}
      <ReservationForm />

      {/* Location Map and Contact */}
      <Contact />

      {/* Footer */}
      <Footer />
    </div>
  );
}

