import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Menu, X, CalendarDays, Phone } from 'lucide-react';

interface NavbarProps {
  onReserveClick: () => void;
}

export default function Navbar({ onReserveClick }: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }

      // Determine active section based on scroll position
      const sections = ['home', 'o-nas', 'menu', 'galeria', 'kontakt'];
      const scrollPosition = window.scrollY + 120;

      for (const section of sections) {
        const el = document.getElementById(section);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { id: 'home', label: 'Start' },
    { id: 'o-nas', label: 'O nas' },
    { id: 'menu', label: 'Menu' },
    { id: 'galeria', label: 'Galeria' },
    { id: 'kontakt', label: 'Kontakt' },
  ];

  const handleLinkClick = (id: string) => {
    setIsMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      const offset = 80; // height of sticky navbar
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <>
      <nav
        id="main-nav"
        className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
          isScrolled
            ? 'bg-beige-50/90 backdrop-blur-md shadow-md border-b border-beige-200/50 py-3'
            : 'bg-transparent py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <div 
              onClick={() => handleLinkClick('home')}
              className="flex flex-col cursor-pointer group"
            >
              <span className="font-serif text-xl sm:text-2xl font-bold tracking-wider text-bordo-500 group-hover:text-gold-600 transition-colors duration-300">
                OSTERIA
              </span>
              <span className="font-serif text-xs tracking-[0.25em] text-gold-600 -mt-1 font-semibold group-hover:text-bordo-500 transition-colors duration-300">
                BELLA VISTA
              </span>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-8">
              {navLinks.map((link) => (
                <button
                  key={link.id}
                  onClick={() => handleLinkClick(link.id)}
                  className={`relative font-sans text-sm tracking-wide font-medium transition-colors duration-300 py-2 cursor-pointer ${
                    activeSection === link.id
                      ? 'text-bordo-500'
                      : 'text-stone-600 hover:text-bordo-500'
                  }`}
                >
                  {link.label}
                  {activeSection === link.id && (
                    <motion.div
                      layoutId="activeIndicator"
                      className="absolute bottom-0 left-0 right-0 h-0.5 bg-gold-500"
                      transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                    />
                  )}
                </button>
              ))}
            </div>

            {/* CTA Button and Mobile Menu Toggle */}
            <div className="flex items-center space-x-4">
              <a 
                href="tel:+48221234567" 
                className="hidden lg:flex items-center space-x-2 text-stone-600 hover:text-bordo-500 text-sm transition-colors duration-300"
              >
                <Phone className="w-4 h-4 text-gold-500" />
                <span className="font-mono">+48 22 123 45 67</span>
              </a>

              <button
                onClick={onReserveClick}
                className="hidden sm:flex items-center space-x-2 bg-bordo-500 hover:bg-bordo-600 text-white px-5 py-2.5 rounded-sm font-sans text-xs uppercase tracking-widest font-semibold shadow-md hover:shadow-lg transition-all duration-300 border border-bordo-600/20 cursor-pointer"
              >
                <CalendarDays className="w-4 h-4 text-gold-300" />
                <span>Zarezerwuj stolik</span>
              </button>

              {/* Mobile menu button */}
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="md:hidden p-2 rounded-md text-stone-600 hover:text-bordo-500 hover:bg-beige-100 transition-colors duration-300 cursor-pointer focus:outline-none"
                aria-label="Toggle Menu"
              >
                {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Mobile Navigation Panel */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3, ease: 'easeInOut' }}
            className="fixed inset-x-0 top-[65px] z-40 bg-beige-50 shadow-xl border-b border-beige-200 py-6 px-4 md:hidden flex flex-col space-y-4"
          >
            <div className="flex flex-col space-y-3">
              {navLinks.map((link) => (
                <button
                  key={link.id}
                  onClick={() => handleLinkClick(link.id)}
                  className={`text-left px-4 py-3 rounded-md text-base font-medium transition-colors duration-200 ${
                    activeSection === link.id
                      ? 'bg-bordo-50 text-bordo-600 font-semibold'
                      : 'text-stone-600 hover:bg-beige-100 hover:text-stone-900'
                  }`}
                >
                  {link.label}
                </button>
              ))}
            </div>

            <div className="border-t border-beige-200/60 pt-4 flex flex-col space-y-4 px-4">
              <div className="flex items-center space-x-3 text-stone-600">
                <Phone className="w-5 h-5 text-gold-500" />
                <span className="font-mono text-sm">+48 22 123 45 67</span>
              </div>
              
              <button
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  onReserveClick();
                }}
                className="w-full flex items-center justify-center space-x-2 bg-bordo-500 hover:bg-bordo-600 text-white py-3 rounded-md font-sans text-sm uppercase tracking-wider font-semibold shadow-md transition-colors duration-200"
              >
                <CalendarDays className="w-4 h-4 text-gold-300" />
                <span>Zarezerwuj stolik</span>
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
