import React from 'react';
import { motion } from 'motion/react';
import { Award, Leaf, Wine, MapPin } from 'lucide-react';

export default function About() {
  const features = [
    {
      icon: <Leaf className="w-6 h-6 text-gold-600" />,
      title: 'Świeże składniki z Włoch',
      description: 'Importujemy oryginalną mąkę Caputo, pomidory San Marzano z Kampanii, ser Pecorino Romano oraz najlepsze oliwy prosto od lokalnych włoskich rzemieślników.'
    },
    {
      icon: <Wine className="w-6 h-6 text-gold-600" />,
      title: 'Kolekcja wybitnych win',
      description: 'Nasz sommelier starannie dobrał kolekcję win z regionów Piemont, Toskania i Veneto, idealnie uzupełniających każde danie z naszej karty.'
    },
    {
      icon: <Award className="w-6 h-6 text-gold-600" />,
      title: 'Tradycja i pasja',
      description: 'Z szacunkiem podchodzimy do klasycznych receptur. Ręcznie wyrabiamy makarony każdego ranka, zachowując pasję i serce włoskiej rodziny.'
    }
  ];

  return (
    <section id="o-nas" className="py-20 sm:py-28 bg-beige-50 relative overflow-hidden">
      {/* Decorative background shapes */}
      <div className="absolute top-20 left-[-10%] w-[30%] h-[30%] bg-gold-200/20 rounded-full filter blur-3xl" />
      <div className="absolute bottom-20 right-[-10%] w-[30%] h-[30%] bg-bordo-100/30 rounded-full filter blur-3xl" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Left Column: Visual Assets - Beautiful Overlapping Images */}
          <div className="lg:col-span-6 relative flex justify-center lg:justify-start">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: '-100px' }}
              transition={{ duration: 0.8 }}
              className="relative w-full max-w-[450px] aspect-[4/5] rounded-sm overflow-hidden shadow-2xl border-4 border-white"
            >
              <img
                src="https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80"
                alt="Wnętrze restauracji Osteria Bella Vista"
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-700"
              />
            </motion.div>

            {/* Overlapping small image */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8, y: 50 }}
              whileInView={{ opacity: 1, scale: 1, y: 0 }}
              viewport={{ once: true, margin: '-100px' }}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="absolute -right-4 -bottom-6 sm:-right-8 sm:-bottom-8 w-[200px] sm:w-[250px] aspect-square rounded-sm overflow-hidden shadow-2xl border-4 border-white hidden sm:block"
            >
              <img
                src="https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?auto=format&fit=crop&w=600&q=80"
                alt="Włoskie wino"
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-700"
              />
            </motion.div>

            {/* Floating Experience Card */}
            <div className="absolute -left-4 top-10 bg-bordo-500 text-white p-5 rounded-sm shadow-xl hidden sm:block max-w-[150px] text-center border border-bordo-400/20">
              <span className="font-serif text-3xl font-bold text-gold-300 block">100%</span>
              <span className="text-[10px] tracking-widest uppercase font-semibold text-gold-100">
                Oryginalne Smaki
              </span>
            </div>
          </div>

          {/* Right Column: Narrative Content */}
          <div className="lg:col-span-6">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-100px' }}
              transition={{ duration: 0.8 }}
            >
              {/* Small Header Badge */}
              <span className="font-serif text-bordo-500 font-medium tracking-widest text-sm uppercase block mb-3">
                Nasza Historia
              </span>
              
              {/* Main Section Title */}
              <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-stone-900 tracking-tight leading-none mb-6">
                Włoska dusza w <span className="text-bordo-500">Warszawie</span>
              </h2>

              {/* Description */}
              <div className="space-y-4 text-stone-600 font-light leading-relaxed mb-10">
                <p>
                  Osteria Bella Vista powstała z głębokiej miłości do tradycji włoskiego biesiadowania. Położona w malowniczym zakątku Warszawy, łączy w sobie elegancję luksusowego lokalu z domowym ciepłem rzymskiej trattorii.
                </p>
                <p>
                  Wierzymy, że jedzenie to nie tylko zaspokajanie głodu, lecz przede wszystkim rytuał, pretekst do spotkania i dzielenia się radością. Nasz Szef Kuchni, pochodzący ze słonecznego Lacjum, dba o to, by każde danie przenosiło naszych gości na kręte, pachnące bazylią i słońcem włoskie uliczki.
                </p>
              </div>

              {/* Feature highlights */}
              <div className="space-y-6">
                {features.map((feature, idx) => (
                  <div key={idx} className="flex items-start space-x-4">
                    <div className="flex-shrink-0 bg-gold-100 p-3 rounded-sm border border-gold-200">
                      {feature.icon}
                    </div>
                    <div>
                      <h3 className="font-serif text-lg font-bold text-stone-900 mb-1">
                        {feature.title}
                      </h3>
                      <p className="text-stone-600 text-sm font-light leading-relaxed">
                        {feature.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Location Tag */}
              <div className="mt-10 pt-8 border-t border-beige-200 flex items-center space-x-3 text-stone-600">
                <MapPin className="w-5 h-5 text-bordo-500" />
                <span className="text-sm font-medium">Lokalizacja: ścisłe centrum Warszawy, ul. Piękna 12</span>
              </div>

            </motion.div>
          </div>

        </div>
      </div>
    </section>
  );
}
