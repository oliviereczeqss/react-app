import React from 'react';
import { motion } from 'motion/react';
import { ArrowDown, CalendarDays, UtensilsCrossed } from 'lucide-react';

interface HeroProps {
  onReserveClick: () => void;
  onMenuClick: () => void;
}

export default function Hero({ onReserveClick, onMenuClick }: HeroProps) {
  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center bg-stone-950 overflow-hidden pt-20"
    >
      {/* Background Image with elegant overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat scale-105 filter brightness-50"
        style={{
          backgroundImage: `url('https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=1920&q=80')`
        }}
      />
      
      {/* Subtle burgundy & gold gradients for deep warmth */}
      <div className="absolute inset-0 bg-gradient-to-t from-bordo-900/90 via-stone-900/50 to-stone-950/40 mix-blend-multiply" />
      <div className="absolute inset-0 bg-gradient-to-r from-bordo-950/45 via-transparent to-black/30" />

      {/* Hero Content Container */}
      <div className="relative max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, ease: 'easeOut' }}
          className="flex flex-col items-center"
        >
          {/* Top Elegant Accent */}
          <div className="flex items-center space-x-3 mb-6">
            <span className="h-[1px] w-8 sm:w-12 bg-gold-400" />
            <span className="font-serif text-gold-400 text-xs sm:text-sm tracking-[0.35em] uppercase font-semibold">
              Tradycja & Nowoczesność
            </span>
            <span className="h-[1px] w-8 sm:w-12 bg-gold-400" />
          </div>

          {/* Restaurant Title */}
          <h1 className="font-serif text-5xl sm:text-7xl md:text-8xl font-bold tracking-tight text-white drop-shadow-xl select-none mb-4">
            Osteria Bella Vista
          </h1>

          {/* Tagline */}
          <p className="font-serif text-lg sm:text-2xl md:text-3xl text-gold-200 tracking-wide font-light max-w-3xl mb-10 drop-shadow-md italic">
            „Smak Włoch w sercu Warszawy”
          </p>

          {/* Description */}
          <p className="text-stone-300 text-sm sm:text-base font-light max-w-2xl leading-relaxed mb-12 px-4">
            Odkryj autentyczną, rzymską kuchnię przygotowywaną według starych receptur przez rodowitych włoskich kucharzy. Poczuj kameralną atmosferę oświetloną blaskiem świec i delektuj się najlepszymi winami w Warszawie.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center gap-4 sm:gap-6 w-full sm:w-auto px-4">
            <button
              onClick={onReserveClick}
              className="w-full sm:w-auto flex items-center justify-center space-x-2 bg-gold-500 hover:bg-gold-600 active:bg-gold-700 text-bordo-950 px-8 py-4 rounded-sm font-sans text-sm uppercase tracking-widest font-bold shadow-xl hover:shadow-gold-500/10 transition-all duration-300 transform hover:-translate-y-0.5 cursor-pointer border border-gold-400/50"
            >
              <CalendarDays className="w-4.5 h-4.5" />
              <span>Zarezerwuj stolik</span>
            </button>

            <button
              onClick={onMenuClick}
              className="w-full sm:w-auto flex items-center justify-center space-x-2 bg-transparent hover:bg-white/10 active:bg-white/5 text-white px-8 py-4 rounded-sm font-sans text-sm uppercase tracking-widest font-bold border border-white/40 hover:border-white transition-all duration-300 transform hover:-translate-y-0.5 cursor-pointer"
            >
              <UtensilsCrossed className="w-4.5 h-4.5 text-gold-400" />
              <span>Zobacz Menu</span>
            </button>
          </div>
        </motion.div>
      </div>

      {/* Decorative Warm Sidelights */}
      <div className="absolute left-0 bottom-0 w-full h-32 bg-gradient-to-t from-beige-50 to-transparent pointer-events-none" />

      {/* Animated Scroll Down Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-15 hidden sm:block">
        <motion.button
          onClick={onMenuClick}
          animate={{ y: [0, 10, 0] }}
          transition={{ repeat: Infinity, duration: 2, ease: 'easeInOut' }}
          className="flex flex-col items-center text-gold-400 hover:text-white transition-colors duration-200 cursor-pointer focus:outline-none"
        >
          <span className="font-mono text-[10px] tracking-widest uppercase mb-2">Przewiń</span>
          <ArrowDown className="w-5 h-5" />
        </motion.button>
      </div>
    </section>
  );
}
